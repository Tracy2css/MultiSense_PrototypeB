using UnityEngine;
using UnityEngine.Rendering.Universal;
using TMPro;

[RequireComponent(typeof(LightProbeUsage))]
public class LuxDetector : MonoBehaviour
{
    [Header("引用")]
    public LightmapLuxCalculator calculator;
    public TextMeshProUGUI displayText;
    
    [Header("检测设置")]
    [Tooltip("更新频率（秒）")]
    public float updateInterval = 0.1f;
    [Tooltip("是否在场景视图中绘制调试信息")]
    public bool drawGizmos = true;
    
    [Header("当前值")]
    [ReadOnly] public float currentLux;
    [ReadOnly] public Color currentLightProbeColor;
    
    private float _timer;
    
    private void Update()
    {
        _timer += Time.deltaTime;
        
        if (_timer >= updateInterval)
        {
            _timer = 0;
            UpdateLuxReading();
        }
    }
    
    private void UpdateLuxReading()
    {
        if (calculator == null || calculator.referenceCoefficientK <= 0)
        {
            currentLux = 0;
            if (displayText != null)
                displayText.text = "请先计算参照系数K";
            return;
        }
        
        // 从光照探针获取当前位置的光照颜色
        currentLightProbeColor = SampleLightProbeColor();
        
        // 计算亮度
        float brightness = 0.2126f * currentLightProbeColor.r + 
                          0.7152f * currentLightProbeColor.g + 
                          0.0722f * currentLightProbeColor.b;
        
        // 使用之前计算的系数K转换为Lux
        currentLux = brightness * calculator.referenceCoefficientK;
        
        // 更新显示
        if (displayText != null)
            displayText.text = $"Lux: {currentLux:F0}";
    }
    
    private Color SampleLightProbeColor()
    {
        // 获取当前位置的光照探针数据
        SphericalHarmonicsL2 sh = new SphericalHarmonicsL2();
        LightProbes.GetInterpolatedProbe(transform.position, null, out sh);
        
        // 从球谐函数中提取基础颜色
        Vector3 ambient = sh[0, 3]; // 基础漫反射分量
        return new Color(ambient.x, ambient.y, ambient.z);
    }
    
    private void OnDrawGizmos()
    {
        if (drawGizmos)
        {
            Gizmos.color = currentLightProbeColor;
            Gizmos.DrawWireSphere(transform.position, 0.1f);
        }
    }
}
