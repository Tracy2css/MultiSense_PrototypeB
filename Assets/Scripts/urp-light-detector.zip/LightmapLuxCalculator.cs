using UnityEngine;
using UnityEngine.Rendering.Universal;

[ExecuteInEditMode]
public class LightmapLuxCalculator : MonoBehaviour
{
    [Header("已知参数")]
    [Tooltip("平行光源的已知Lux值")]
    public float directionalLightLux = 130000f;
    
    [Header("引用")]
    [Tooltip("场景中的平行光源")]
    public Light directionalLight;
    [Tooltip("当前使用的Lightmap数据")]
    public LightmapData targetLightmapData;
    
    [Header("计算结果")]
    [ReadOnly] public float referenceCoefficientK;
    [ReadOnly] public float lightmapAverageBrightness;
    
    [ContextMenu("计算参照系数K")]
    public void CalculateReferenceCoefficient()
    {
        if (directionalLight == null)
        {
            Debug.LogError("请指定平行光源");
            return;
        }
        
        if (targetLightmapData == null || targetLightmapData.lightmapColor == null)
        {
            Debug.LogError("请指定有效的Lightmap数据");
            return;
        }
        
        // 确保平行光源是平行光类型
        if (directionalLight.type != LightType.Directional)
        {
            Debug.LogError("指定的光源不是平行光源");
            return;
        }
        
        // 计算Lightmap的平均亮度
        lightmapAverageBrightness = CalculateAverageLightmapBrightness(targetLightmapData);
        
        // 计算参照系数 k = 已知Lux值 / Lightmap平均亮度
        referenceCoefficientK = directionalLightLux / lightmapAverageBrightness;
        
        Debug.Log($"计算完成 - 参照系数K: {referenceCoefficientK}, Lightmap平均亮度: {lightmapAverageBrightness}");
    }
    
    private float CalculateAverageLightmapBrightness(LightmapData lightmapData)
    {
        Texture2D lightmapTexture = lightmapData.lightmapColor;
        
        // 对于大尺寸的lightmap，我们采样部分像素而不是全部以提高性能
        const int sampleStep = 10;
        float totalBrightness = 0;
        int sampleCount = 0;
        
        for (int y = 0; y < lightmapTexture.height; y += sampleStep)
        {
            for (int x = 0; x < lightmapTexture.width; x += sampleStep)
            {
                Color pixelColor = lightmapTexture.GetPixel(x, y);
                // 转换为亮度 (使用Rec.709标准)
                float brightness = 0.2126f * pixelColor.r + 0.7152f * pixelColor.g + 0.0722f * pixelColor.b;
                totalBrightness += brightness;
                sampleCount++;
            }
        }
        
        return totalBrightness / sampleCount;
    }
}
